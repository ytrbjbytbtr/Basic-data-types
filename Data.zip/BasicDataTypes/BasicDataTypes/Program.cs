﻿using System;

namespace BasicDataTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            string MyName = "Sava";
            byte MyAge = 23;
            bool HaveIApet = true;
            double MyShoeSize = 36.5;

            Console.WriteLine("My name is " + MyName);
            Console.WriteLine("MyAge " + MyAge);
            Console.WriteLine("Do I have a pet? " + HaveIApet);
            Console.WriteLine("My shoe size is " + MyShoeSize);
        }
    }
}
